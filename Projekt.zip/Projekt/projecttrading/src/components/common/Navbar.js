import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css'; 

const Navbar = () => {
  return (
    <nav className="navbar">
      <ul className="navbar-list">
        <li className="navbar-item">
          <Link to="/menu" className="navbar-link">Menu</Link>
        </li>
        <li className="navbar-item">
          <Link to="/journey" className="navbar-link">Consistency</Link>
        </li>
        <li className="navbar-item">
          <Link to="/balance" className="navbar-link">Balance</Link>
        </li>
        <li className="navbar-item">
          <Link to="/notes" className="navbar-link">Notes</Link>
        </li>
        <li className="navbar-item">
          <Link to="/trades" className="navbar-link">MyTrades</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;