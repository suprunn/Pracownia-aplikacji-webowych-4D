import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './common/Navbar';
import Menu from './pages/Menu';
import Balance from './pages/Balance';

import Notes from './pages/Notes'
import Journey from './pages/Journey'
import Trades from './pages/Trades'

const App = () => {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/menu" element={<Menu />} />
          <Route path="/journey" element={<Journey/>} />
          <Route path="/balance" element={<Balance />} />
          <Route path="/notes" element={<Notes/>} />
          <Route path="/trades" element={<Trades/>} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;