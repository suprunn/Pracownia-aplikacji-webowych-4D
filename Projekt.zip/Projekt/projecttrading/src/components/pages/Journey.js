import React, { useState } from 'react';
import '../styles/journey.css';

const Journey = () => {
  const [markedDays, setMarkedDays] = useState([]);

 const currentDate = new Date();
  const endDate = new Date('2024-12-31');
  const millisecondsPerDay = 24 * 60 * 60 * 1000;
  const daysRemaining = Math.ceil((endDate - currentDate) / millisecondsPerDay);

  const daysInMonth = 31;
  const calendarDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const handleDayClick = (day) => {
    const index = markedDays.indexOf(day);
    if (index === -1) {
      
      setMarkedDays([...markedDays, day]);
    } else {
      
      const updatedMarkedDays = [...markedDays];
      updatedMarkedDays.splice(index, 1);
      setMarkedDays(updatedMarkedDays);
    }
  };

  const progress = (markedDays.length / daysInMonth) * 100;

  return (
    <div className="journey-container">
    <div className="counter">
        <div className='counterdays'>
        Days remaining until the end of 2024: 
        </div>
        <div className='days'>{daysRemaining}</div>
    </div>
    
      

      <div className="calendar-header">
        <h1>Daily consistency </h1>
        </div>
      <div className="mini-calendar">
        {calendarDays.map((day) => (
          <div
            key={day}
            className={`calendar-day ${markedDays.includes(day) ? 'marked' : ''}`}
            onClick={() => handleDayClick(day)}
          >
            {day}
            {markedDays.includes(day) && <div className="mark-box"></div>}
          </div>
        ))}
      </div>
     
      <div className="progress-bar">
        <div className="progress" style={{ width: `${progress}%` }}></div>
      </div>
    </div>
  );
};

export default Journey;