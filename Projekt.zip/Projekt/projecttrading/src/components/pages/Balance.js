import React, { useState } from 'react';
import '../styles/Balance.css';


const Balance = () => {
  const [currentProfit, setCurrentProfit] = useState(0);
  const [profitInput, setProfitInput] = useState('0');
  const [tradeType, setTradeType] = useState('Long');
  const [selectedPair, setSelectedPair] = useState('EUR/USD');
  const [selectedDate, setSelectedDate] = useState('');
  const [history, setHistory] = useState([]);
  const [entryCount, setEntryCount] = useState(0);

  const handleAdd = () => {
    const profit = parseFloat(profitInput);
    const newCurrentProfit = parseFloat((currentProfit + profit).toFixed(2));
    setCurrentProfit(newCurrentProfit);
    const newHistory = [
      {
        entryNumber: entryCount + 1,
        profitInput: profit.toFixed(2) + '%',
        tradeType,
        selectedPair,
        selectedDate,
        currentProfit: newCurrentProfit,
        timestamp: new Date().toLocaleString(),
      },
      ...history,
    ];
    setHistory(newHistory.slice(0, 20));
    setProfitInput('0');
    setEntryCount(entryCount + 1);
  };

  const handleAddAndPrint = () => {
    handleAdd();
  };

 

  return (
  <section id ="pagebalance">
    <section id="balance">
      <header className="header">Balance</header>

      
      <h1>Current profit: {currentProfit.toFixed(2)}%</h1>

      <label htmlFor="profitInput">Profit in %:</label>
      <input
        type="number"
        id="profitInput"
        value={profitInput}
        onChange={(event) => setProfitInput(event.target.value)}
      />

      <label htmlFor="tradeTypeSelect">Trade Type:</label>
      <select
        id="tradeTypeSelect"
        value={tradeType}
        onChange={(event) => setTradeType(event.target.value)}
      >
        <option value="Long">Long</option>
        <option value="Short">Short</option>
      </select>

      <label htmlFor="pairSelect">Currency pair:</label>
      <select
        id="pairSelect"
        value={selectedPair}
        onChange={(event) => setSelectedPair(event.target.value)}
      >
        <option value="EUR/USD">EUR/USD</option>
        <option value="GBP/USD">GBP/USD</option>
      </select>

      <label htmlFor="selectedDate">Select Date</label>
      <div className="date-picker">
        <input
          type="date"
          id="selectedDate"
          value={selectedDate}
          onChange={(event) => setSelectedDate(event.target.value)}
          className="custom-date-picker"
        />
      </div>

      <div>
        <button className='buttonAdd' onClick={handleAddAndPrint}>Add</button>
      </div>

      <div className="history-box">
        <h3>History <br></br>
        ...</h3>
        {history.map((entry, index) => (
          <div key={index} className="history-entry">
            <p>
              <strong>Entry: </strong>{entry.entryNumber},  {' '}
              <strong>Profit: </strong>{entry.profitInput},  {' '}
              <strong>Trade Type: </strong>{entry.tradeType},  {' '}
              <strong>Pair of Trade: </strong>{entry.selectedPair},{' '}
              <strong>Date: </strong>{entry.selectedDate},{' '}
              <strong>Current Profit: </strong>{entry.currentProfit.toFixed(2)}%,{' '}
              <strong>Time added: </strong>{' '}
                {new Date(entry.timestamp).toLocaleTimeString()}
            </p>
          </div>
        ))}
      </div>
    </section>
  </section>
  );
};

export default Balance;