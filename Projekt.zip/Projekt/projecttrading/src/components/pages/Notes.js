import React, { useState } from 'react';
import '../styles/Notes.css';



const Notes = () => {
  const [note, setNote] = useState('');
  const [tradeDescriptions, setTradeDescriptions] = useState([]);
  const [noteCount, setNoteCount] = useState(0);
  const [editIndex, setEditIndex] = useState(null);

  const handleAccept = () => {
    if (editIndex !== null) {
      const updatedDescriptions = tradeDescriptions.map((desc, index) =>
        index === editIndex ? `${editIndex + 1}. ${note}` : desc
      );
      setTradeDescriptions(updatedDescriptions);
      setEditIndex(null);
    } else {
      const newTradeDescriptions = [...tradeDescriptions, `${noteCount + 1}. ${note}`];
      setTradeDescriptions(newTradeDescriptions);
      setNoteCount(noteCount + 1);
    }
    setNote('');
  };

  const handleEdit = (index) => {
    setEditIndex(index);
    setNote(tradeDescriptions[index].substring(tradeDescriptions[index].indexOf('.') + 2));
  };

  const handleDelete = (index) => {
    const updatedDescriptions = tradeDescriptions.filter((_, i) => i !== index);
    setTradeDescriptions(updatedDescriptions);
  };

  return (
    <div className="notes-container">
      <h1>Notes</h1>
      <textarea
        className="notes-textarea"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Write your notes here..."
      />
      <button className='buttonAcc' onClick={handleAccept}>{editIndex !== null ? 'Update' : 'Accept'}</button>

      <div className="trade-descriptions">
        <h3>Usefull tips <br></br>
          ...
        </h3>
        {tradeDescriptions.map((description, index) => (
          <div key={index} className="note-entry">
            <p>{description}</p>
            <div>
              <button className='buttonEdit' onClick={() => handleEdit(index)}>Edit</button>
              <button className='buttonDel' onClick={() => handleDelete(index)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Notes;