
import React from 'react';
import '../styles/Menu.css';

const Menu = () => {
  return (
    <div className="bodybackground">

      <div className="header-menu">
      <h1>Aplikacja webowa</h1>
      
        <div className='description'>
          <p>Jest to Aplikacja webowa która powinna pomóc mi w śledzeniu mojego postepu jak i zapisywania informacij przydatnych do uprawiania Tradingu, którym się interesuję. Aplikacje w react robiłem pierwszy raz więc mogą być różne błędy nie w kodzie lecz ogólne importowania itp. ponieważ na początku miałem duże problemy z samą budową struktury plików aplikacij... </p>
          <p>Zrobiłem tą aplkacja z czasami mniejszą lecz czasami większą  pomocą chat-gpt jak będzie pan mógł zobaczyć w kodzie, postanowiłem tak ponieważ próbując na początku korzystać tylko ze źródeł jak youtube oraz różne fora z odpowiedziami na moje pytania i w celu uzyskania pomocy nie byłem w stanie napisać tej aplikacji jak chciałem więc użyłem chat-gpt który w mojej opinii potrafi dobrzę wytłumaczyć i pomóc w nauce na takim projekcie. </p>
          <p>Jest to aplikacja która na ten czas nie ma większego zastosowania ponieważ nie ma połaczenia z bazą danych i żadne dane nie są zapisywane i przechowywania lecz chcę ją przebudować lub napisać taką która będzie miała połączenie z bazą abym persolanie mógł z niej korzystać.</p>
          <p>Nie oddałem aplikacji z bazą danych ponieważ moim zdaniem poprostu bym jej nie zdążył zrobić więc oddaje taką wersję aby mógł mi pan wystawić ocenę na półrocze.  </p>
        </div>
      </div>
      
    </div>
  );
};

export default Menu;