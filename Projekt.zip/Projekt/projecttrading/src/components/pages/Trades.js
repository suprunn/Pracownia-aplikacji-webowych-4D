import React, { useState } from 'react';
import '../styles/Trades.css';

const Trades = () => {
  const [bestImage, setBestImage] = useState(null);
  const [bestDescription, setBestDescription] = useState('');
  const [bestDate, setBestDate] = useState('');
  const [bestPips, setBestPips] = useState('');
  const [bestProfit, setBestProfit] = useState('');
  const [bestQuality, setBestQuality] = useState(1);

  const [allImage, setAllImage] = useState(null);
  const [allDescription, setAllDescription] = useState('');
  const [allDate, setAllDate] = useState('');
  const [allPips, setAllPips] = useState('');
  const [allProfit, setAllProfit] = useState('');
  const [allQuality, setAllQuality] = useState(1);

  const handleBestImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setBestImage(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleBestDescriptionChange = (e) => {
    setBestDescription(e.target.value);
  };

  const handleBestDateChange = (e) => {
    setBestDate(e.target.value);
  };

  const handleBestPipsChange = (e) => {
    setBestPips(e.target.value);
  };

  const handleBestProfitChange = (e) => {
    setBestProfit(e.target.value);
  };

  const handleBestQualityChange = (e) => {
    setBestQuality(parseInt(e.target.value, 10));
  };

  const handleAllImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setAllImage(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleAllDescriptionChange = (e) => {
    setAllDescription(e.target.value);
  };

  const handleAllDateChange = (e) => {
    setAllDate(e.target.value);
  };

  const handleAllPipsChange = (e) => {
    setAllPips(e.target.value);
  };

  const handleAllProfitChange = (e) => {
    setAllProfit(e.target.value);
  };

  const handleAllQualityChange = (e) => {
    setAllQuality(parseInt(e.target.value, 10));
  };

  return (
    
    <div className="trades-container">
   
      <div className="block-container">
        
        <div className="block"> {/* 1 */}
          <h2>Best Trades (uploaded images)</h2>
          <div className="image-upload">
            <input
              type="file"
              accept="image/*"
              onChange={handleBestImageUpload}
            />
            {bestImage && <img src={bestImage} alt="Best Ones" className="uploaded-image" />}
          </div>
          <textarea
            value={bestDescription}
            onChange={handleBestDescriptionChange}
            placeholder="Enter your description..."
            className="description-textarea"
          />
        </div>
        {/* 2 */}
        <div className="block">
          <h2>Results</h2>
          <label>Date:</label>
          <input type="date" value={bestDate} onChange={handleBestDateChange} />
          <label>Number of pips:</label>
          <input type="number" value={bestPips} onChange={handleBestPipsChange} />
          <label>Profit in $:</label>
          <input type="number" value={bestProfit} onChange={handleBestProfitChange} />
          <label>Quality of trades:</label>
          <input type="number" min="1" max="10" value={bestQuality}onChange={handleBestQualityChange}
          />
          <button>(add to database/and save in app)</button> {/* plany na wersje z bazą danych... Teraz nie jestem w stanie skorzystać z tych danych w żaden sposób*/}
        </div>
        {/* 3 */}
        <div className="block">
          <h2>All Trades (uploaded images)</h2>
          <div className="image-upload">
            <input
            
              type="file"
              accept="image/*"
              onChange={handleAllImageUpload}
            />
            {allImage && <img src={allImage} alt="All Trades" className="uploaded-image" />}
          </div>
          <textarea
            value={allDescription}
            onChange={handleAllDescriptionChange}
            placeholder="Enter your description..."
            className="description-textarea"
          />
        </div>
        
        <div className="block"> {/* 4 */}
          <h2>Results</h2>
          <label>Date:</label>
          <input type="date" value={allDate} onChange={handleAllDateChange} />
          <label>Number of pips:</label>
          <input type="number" value={allPips} onChange={handleAllPipsChange} />
          <label>Profit in $:</label>
          <input type="number" value={allProfit} onChange={handleAllProfitChange} />
          <label>Quality of trades:</label>
          <input type="number" min="1" max="10" value={allQuality} onChange={handleAllQualityChange}
          />
          <button>(add to database/and save in app)</button> {/* plany na wersje z bazą danych... Teraz nie jestem w stanie skorzystać z tych danych w żaden sposób*/}
          
        </div>
      </div>
    </div>
  );
};

export default Trades;